package agents.exo1;
import jade.core.Agent;


/**
 * Do nothing
 * @author hc
 *
 */
public class AgentEmpty extends Agent{

}
